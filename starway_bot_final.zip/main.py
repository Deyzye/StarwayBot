# main.py — точка входа

print('Star Way запущен')